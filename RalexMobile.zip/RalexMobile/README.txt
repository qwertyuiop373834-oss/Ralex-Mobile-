RALEX MOBILE - quraşdırma

1) Android Studio-da bu qovluğu açın (File > Open) və Gradle Sync gözləyin.
2) AI modelini yükləyin:
   TensorFlow Hub: "captain-pool esrgan-tf2 lite" (ESRGAN, 50x50 -> 200x200)
   Faylı "esrgan.tflite" adı ilə bura qoyun:
   app/src/main/assets/esrgan.tflite
3) Telefonu qoşub Run basın.

Qeydlər:
- Qısa videolarla (5-10 san) başlayın, emal yavaşdır.
- Nəticə: Android/data/az.ralex.mobile/files/Movies/ qovluğunda.
