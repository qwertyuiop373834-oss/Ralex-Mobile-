package az.ralex.mobile

import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    private var videoUri: Uri? = null
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var startBtn: Button

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        videoUri = uri
        startBtn.isEnabled = uri != null
        status.text = if (uri != null) "Video seçildi" else "Video seçilmədi"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Ralex Mobile"; textSize = 28f; gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "AI ilə video keyfiyyətini yaxşılaşdır"; gravity = Gravity.CENTER
        })
        val pick = Button(this).apply { text = "Video seç" }
        startBtn = Button(this).apply { text = "Yaxşılaşdır"; isEnabled = false }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        status = TextView(this).apply { gravity = Gravity.CENTER; text = "Hazırdır" }
        listOf(pick, startBtn, progress, status).forEach { root.addView(it) }
        setContentView(root)

        pick.setOnClickListener { picker.launch("video/*") }
        startBtn.setOnClickListener {
            val uri = videoUri ?: return@setOnClickListener
            val out = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "ralex_${System.currentTimeMillis()}.mp4")
            startBtn.isEnabled = false
            lifecycleScope.launch {
                try {
                    VideoEnhancer.enhance(this@MainActivity, uri, out) { p ->
                        runOnUiThread { progress.progress = p; status.text = "Emal olunur: $p%" }
                    }
                    status.text = "Hazırdır!\n${out.absolutePath}"
                } catch (e: Exception) {
                    status.text = "Xəta: ${e.message}"
                }
                startBtn.isEnabled = true
            }
        }
    }
}
