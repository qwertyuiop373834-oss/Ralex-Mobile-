package az.ralex.mobile

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.ceil

/** ESRGAN (TFLite) ilə 4x böyütmə. Model: 50x50 giriş -> 200x200 çıxış. */
class Upscaler(context: Context) {
    private val interpreter: Interpreter
    private val inBuf = ByteBuffer.allocateDirect(50 * 50 * 3 * 4).order(ByteOrder.nativeOrder())
    private val outBuf = ByteBuffer.allocateDirect(200 * 200 * 3 * 4).order(ByteOrder.nativeOrder())

    init {
        val fd = context.assets.openFd("esrgan.tflite")
        val model = FileInputStream(fd.fileDescriptor).channel
            .map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
        interpreter = Interpreter(model, Interpreter.Options().apply { setNumThreads(4) })
    }

    /** Çıxış ölçüsü: (ceil(w/50)*200, ceil(h/50)*200) */
    fun outputSize(w: Int, h: Int) =
        Pair(ceil(w / 50.0).toInt() * 200, ceil(h / 50.0).toInt() * 200)

    fun upscale(src: Bitmap): Bitmap {
        val cols = ceil(src.width / 50.0).toInt()
        val rows = ceil(src.height / 50.0).toInt()
        val scaled = Bitmap.createScaledBitmap(src, cols * 50, rows * 50, true)
        val out = Bitmap.createBitmap(cols * 200, rows * 200, Bitmap.Config.ARGB_8888)
        val inPix = IntArray(50 * 50)
        val outPix = IntArray(200 * 200)

        for (r in 0 until rows) for (c in 0 until cols) {
            scaled.getPixels(inPix, 0, 50, c * 50, r * 50, 50, 50)
            inBuf.rewind()
            for (p in inPix) {
                inBuf.putFloat(((p shr 16) and 255).toFloat())
                inBuf.putFloat(((p shr 8) and 255).toFloat())
                inBuf.putFloat((p and 255).toFloat())
            }
            inBuf.rewind(); outBuf.rewind()
            interpreter.run(inBuf, outBuf)
            outBuf.rewind()
            for (i in outPix.indices) {
                val rr = outBuf.float.coerceIn(0f, 255f).toInt()
                val gg = outBuf.float.coerceIn(0f, 255f).toInt()
                val bb = outBuf.float.coerceIn(0f, 255f).toInt()
                outPix[i] = (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
            }
            out.setPixels(outPix, 0, 200, c * 200, r * 200, 200, 200)
        }
        if (scaled !== src) scaled.recycle()
        return out
    }

    fun close() = interpreter.close()
}
