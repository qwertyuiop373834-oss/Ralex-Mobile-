package az.ralex.mobile

import android.content.Context
import android.graphics.Bitmap
import android.media.*
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import kotlin.coroutines.coroutineContext

object VideoEnhancer {
    private const val FPS = 24
    private const val MAX_SIDE = 360 // giriş kadrının maksimum tərəfi (sürət üçün)

    suspend fun enhance(
        context: Context, uri: Uri, outFile: File, onProgress: (Int) -> Unit
    ) = withContext(Dispatchers.Default) {
        val mmr = MediaMetadataRetriever().apply { setDataSource(context, uri) }
        val durMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong()
        val first = mmr.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST)
            ?: error("Video oxunmadı")

        val k = minOf(1f, MAX_SIDE / maxOf(first.width, first.height).toFloat())
        val tw = (first.width * k).toInt().coerceAtLeast(50)
        val th = (first.height * k).toInt().coerceAtLeast(50)

        val upscaler = Upscaler(context)
        val (ow, oh) = upscaler.outputSize(tw, th)

        // --- Video encoder ---
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, ow, oh).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 8_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = enc.createInputSurface()
        enc.start()

        // --- Səs trekini tap ---
        val audioEx = MediaExtractor().apply { setDataSource(context, uri, null) }
        var audioFormat: MediaFormat? = null
        for (i in 0 until audioEx.trackCount) {
            val f = audioEx.getTrackFormat(i)
            if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                audioEx.selectTrack(i); audioFormat = f; break
            }
        }

        val muxer = MediaMuxer(outFile.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var vTrack = -1; var aTrack = -1; var started = false
        var outCount = 0L
        val frameUs = 1_000_000L / FPS
        val info = MediaCodec.BufferInfo()

        fun drain(end: Boolean) {
            while (true) {
                val idx = enc.dequeueOutputBuffer(info, 10_000)
                when {
                    idx == MediaCodec.INFO_TRY_AGAIN_LATER -> if (!end) return
                    idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        vTrack = muxer.addTrack(enc.outputFormat)
                        audioFormat?.let { aTrack = muxer.addTrack(it) }
                        muxer.start(); started = true
                    }
                    idx >= 0 -> {
                        val buf = enc.getOutputBuffer(idx)!!
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (info.size > 0 && started) {
                            info.presentationTimeUs = outCount++ * frameUs
                            muxer.writeSampleData(vTrack, buf, info)
                        }
                        enc.releaseOutputBuffer(idx, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                    }
                }
            }
        }

        // --- Kadr-kadr emal ---
        val total = (durMs * FPS / 1000).toInt().coerceAtLeast(1)
        for (i in 0 until total) {
            if (!coroutineContext.isActive) break
            val raw = mmr.getFrameAtTime(i * 1_000_000L / FPS, MediaMetadataRetriever.OPTION_CLOSEST)
                ?: continue
            val small = Bitmap.createScaledBitmap(raw, tw, th, true)
            val big = upscaler.upscale(small)
            val canvas = surface.lockCanvas(null)
            canvas.drawBitmap(big, 0f, 0f, null)
            surface.unlockCanvasAndPost(canvas)
            raw.recycle(); small.recycle(); big.recycle()
            drain(false)
            onProgress((i + 1) * 100 / total)
        }
        enc.signalEndOfInputStream()
        drain(true)

        // --- Səsi köçür ---
        if (started && aTrack >= 0) {
            val buf = ByteBuffer.allocate(1 shl 20)
            val ai = MediaCodec.BufferInfo()
            while (true) {
                buf.clear()
                val n = audioEx.readSampleData(buf, 0)
                if (n < 0) break
                ai.set(0, n, audioEx.sampleTime, audioEx.sampleFlags)
                muxer.writeSampleData(aTrack, buf, ai)
                audioEx.advance()
            }
        }

        if (started) muxer.stop()
        muxer.release(); enc.stop(); enc.release(); surface.release()
        audioEx.release(); mmr.release(); upscaler.close()
    }
}
